package com.example.demo.domain;

public @interface Business {

}
