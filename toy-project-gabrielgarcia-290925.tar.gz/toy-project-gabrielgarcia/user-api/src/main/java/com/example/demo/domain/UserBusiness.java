package com.example.demo.domain;

@Business
public class UserBusiness {
    
    public void CadastrarUsuario() {
        System.out.println("cadastro");
    }
}
