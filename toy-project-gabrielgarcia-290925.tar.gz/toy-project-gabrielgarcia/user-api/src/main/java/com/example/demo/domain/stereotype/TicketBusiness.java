package com.example.demo.domain.stereotype;

public class TicketBusiness {
    
}
